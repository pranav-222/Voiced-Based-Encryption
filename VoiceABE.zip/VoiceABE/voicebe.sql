/*
SQLyog Community v11.51 (32 bit)
MySQL - 5.5.42 : Database - voiceabe
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`voiceabe` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `voiceabe`;

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `MESSAGEID` int(11) NOT NULL,
  `MESSAGE` varchar(255) DEFAULT NULL,
  `SENDER` varchar(255) DEFAULT NULL,
  `MESSAGEDATE` varchar(255) DEFAULT NULL,
  `SECKEY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MESSAGEID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `message` */

insert  into `message`(`MESSAGEID`,`MESSAGE`,`SENDER`,`MESSAGEDATE`,`SECKEY`) values (1,'o4WUx+UsspkrcV1ek13sng==\r\n','srinu','Sun Mar 24 16:53:54 IST 2019','5eIF6jOjMhRw');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `USERID` varchar(255) NOT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `USERTYPE` varchar(255) DEFAULT NULL,
  `GENDER` varchar(255) DEFAULT NULL,
  `AGE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`USERID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`USERID`,`NAME`,`PASSWORD`,`USERTYPE`,`GENDER`,`AGE`) values ('raju','raju','raju','faculty','male','26'),('ram','ram','ram','student','male','25'),('srinu','srinu','srinu','student','male','25');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
