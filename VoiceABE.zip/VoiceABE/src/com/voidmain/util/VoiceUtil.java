package com.voidmain.util;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class VoiceUtil {

	public static final String VOICENAME = "kevin";
	
	public static Voice getVoice()
	{
		Voice voice=VoiceManager.getInstance().getVoice(VoiceUtil.VOICENAME);
		voice.allocate();
		voice.setDurationStretch(1.3f);
		
		return voice; 
	}
}
