package com.voidmain.dao;

import java.util.List;

import com.voidmain.pojo.Message;
import com.voidmain.pojo.User;

public class HibernateDAO {

	public static boolean isValidUser(String studentname,String password)
	{
		boolean isValid=false;

		User user=getUserById(studentname);

		if(user!=null && user.getPassword().equals(password))
		{
			isValid=true;
		}

		return isValid;
	}


	//============================================================================

	public static User getUserById(String id)
	{
		return (User)HibernateTemplate.getObject(User.class,id);
	}

	public static int deleteUser(String id)
	{
		return HibernateTemplate.deleteObject(User.class,id);
	}

	public static List<User> getUsers()
	{
		List<User> users=(List)HibernateTemplate.getObjectListByQuery("From User");

		return users;
	}
	
	//===============================================================================
	
	public static Message getMessageById(int id)
	{
		return (Message)HibernateTemplate.getObject(Message.class,id);
	}

	public static int deleteMessage(int id)
	{
		return HibernateTemplate.deleteObject(Message.class,id);
	}

	public static List<Message> getMessage()
	{
		List<Message> messages=(List)HibernateTemplate.getObjectListByQuery("From Message");

		return messages;
	}
	
	//=========================================================================
}
