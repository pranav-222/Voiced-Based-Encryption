package com.voidmain.service;

import java.util.Random;

public class KeyGenerator {

	public static String getKey()
	{
		Random r = new Random();

		String pattern = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJLMNIOPQRSTUVWXYZ";
		
		String key="";
		
		for (int j = 0; j < 12; j++) {

			key=key+pattern.charAt(r.nextInt(60));
		}
		
		return key;
	}
}
